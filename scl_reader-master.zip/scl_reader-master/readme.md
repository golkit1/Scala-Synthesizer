# scl_reader

Simple Scala .scl tuning files reader for Cycling'74 Max `[js]` object. The aim of this project is to provide a simple way to use one of many tunings available in Scala format.